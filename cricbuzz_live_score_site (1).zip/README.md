# Cricbuzz-style Live Cricket Score Website

This is a Firebase-based live score website for local tournaments. Includes:
- `index.html`: Live viewer page
- `admin.html`: Admin score update panel
- Firebase Realtime Database integration
- GitHub Pages support

## Deployment
1. Upload files to GitHub
2. Enable GitHub Pages (main branch / root)
3. Access your live site
